# INFO 2300 - Project 3

Open this repository as a Codespace on GitHub (or as a container in VS Code.)

## Design Plan

Document your design and your plan in the [design journey](design-plan/design-journey.md).

## Development Server

From the **Run** menu, select **Start Debugging**.

Visit <http://127.0.0.1:8080/> in a browser to access the development server.
