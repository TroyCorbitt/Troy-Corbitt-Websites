
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title><?php echo htmlspecialchars($page_title); ?></title>

  <link rel="stylesheet" type="text/css" href="/styles/site.css">
  <!-- Source: (original work) Troy Corbitt -->
