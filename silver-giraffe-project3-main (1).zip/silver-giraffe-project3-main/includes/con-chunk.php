<li class="con-row">
  <ul>
    <?php foreach ($chunk as $record) : ?>
      <?php include "includes/con-song.php"; ?>
    <?php endforeach; ?>
  </ul>
</li>
<!-- Source: (original work) Xiaoxin Li -->
