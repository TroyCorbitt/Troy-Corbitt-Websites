<?php

const RATING_ARTISTS = array(
    1 => "The Beatles",
    2 => "Madonna",
    3 => "Bob Dylan",
    4 => "Michael Jackson",
    5 => "Beyoncé",
    6 => "Elvis Presley",
    7 => "Prince",
    8 => "David Bowie",
    9 => "Nirvana",
    10 => "Aretha Franklin",
    11 => "Freddie Mercury (Queen)",
    12 => "Stevie Wonder",
    13 => "Taylor Swift",
    14 => "Jimi Hendrix",
    15 => "Billie Holiday",
    16 => "Frank Sinatra",
    17 => "Lady Gaga",
    18 => "The Rolling Stones",
    19 => "Adele",
    20 => "Kanye West",
);

const RATING_ALBUMS = array(
    50 => "Echoes of Tomorrow",
    51 => "Shadows in the Sunlight",
    52 => "Rhythms of the Lost City",
    53 => "Beneath the Velvet Sky",
    54 => "Whispers of the Ancient",
    55 => "Dancing in the Neon Rain",
    56 => "Harmony in Chaos",
    57 => "Sirens of the Silent Sea",
    58 => "Voyage Beyond the Stars",
    59 => "Legends of the Forgotten Time",
    60 => "In the Heart of the Storm",
    61 => "Dreams of the Phoenix",
    62 => "Reflections of the Soul",
    63 => "Echoes from the Abyss",
    64 => "Light in the Shadow Realm",
    65 => "Melodies of a Distant World",
    66 => "Tales from the Edge of Reality",
    67 => "Paths of the Wanderer",
    68 => "Whispers Among the Ruins",
    69 => "Beyond the Horizon",
    70 => "The Last Ember of Dusk"
);

?>
 <!-- Source: (original work) Troy Corbitt -->
